from django.apps import AppConfig


class DaftarFavoritConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'daftar_favorit'
