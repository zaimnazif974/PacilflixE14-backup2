from django.apps import AppConfig


class DaftarUnduhanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'daftar_unduhan'
