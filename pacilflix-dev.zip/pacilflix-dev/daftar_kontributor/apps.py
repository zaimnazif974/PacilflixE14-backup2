from django.apps import AppConfig


class DaftarKontributorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'daftar_kontributor'
